package com.example.demo.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the site_master database table.
 * 
 */
import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
@Table(name="site_master")
//@JsonFormat(shape=JsonFormat.Shape.ARRAY)
public class SiteMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="site_id")
	private String siteId;

	private String address1;

	private String address2;

	@Column(name="alert_setting")
	private Byte alertSetting;

	private String city;

	private String country;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;

	private String description;

	@Column(name="index_created")
	private Byte indexCreated;

	@Column(name="is_active")
	private Byte isActive;

	@Column(name="is_deleted")
	private Byte isDeleted;

	private Double latitude;

	private Double longitude;

	@Column(name="metric_unit")
	private String metricUnit;

	@Column(name="modified_by")
	private String modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="site_name")
	private String siteName;

	@Column(name="site_unique_id")
	private String siteUniqueId;

	private String state;

	@Column(name="streaming_enabled")
	private Byte streamingEnabled;

	@Column(name="time_zone")
	private String timeZone;

	@Column(name="tunnel_efficiency_threshold")
	private Double tunnelEfficiencyThreshold;

	@Column(name="tunnel_idle_minute")
	private int tunnelIdleMinute;

	@Column(name="tunnel_turn_minute")
	private int tunnelTurnMinute;

	@Column(name="washer_efficiency_threshold")
	private Double washerEfficiencyThreshold;

	@Column(name="washer_idle_minute")
	private int washerIdleMinute;

	@Column(name="washer_turn_minute")
	private int washerTurnMinute;

	private String zipcode;


	public SiteMaster() {
	}


	public String getSiteId() {
		return this.siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getAddress1() {
		return this.address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return this.address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public Byte getAlertSetting() {
		return this.alertSetting;
	}

	public void setAlertSetting(Byte alertSetting) {
		this.alertSetting = alertSetting;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Byte getIndexCreated() {
		return this.indexCreated;
	}

	public void setIndexCreated(Byte indexCreated) {
		this.indexCreated = indexCreated;
	}

	public Byte getIsActive() {
		return this.isActive;
	}

	public void setIsActive(Byte isActive) {
		this.isActive = isActive;
	}

	public Byte getIsDeleted() {
		return this.isDeleted;
	}

	public void setIsDeleted(Byte isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Double getLatitude() {
		return this.latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return this.longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getMetricUnit() {
		return this.metricUnit;
	}

	public void setMetricUnit(String metricUnit) {
		this.metricUnit = metricUnit;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getSiteName() {
		return this.siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getSiteUniqueId() {
		return this.siteUniqueId;
	}

	public void setSiteUniqueId(String siteUniqueId) {
		this.siteUniqueId = siteUniqueId;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Byte getStreamingEnabled() {
		return this.streamingEnabled;
	}

	public void setStreamingEnabled(Byte streamingEnabled) {
		this.streamingEnabled = streamingEnabled;
	}

	public String getTimeZone() {
		return this.timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public Double getTunnelEfficiencyThreshold() {
		return this.tunnelEfficiencyThreshold;
	}

	public void setTunnelEfficiencyThreshold(Double tunnelEfficiencyThreshold) {
		this.tunnelEfficiencyThreshold = tunnelEfficiencyThreshold;
	}

	public int getTunnelIdleMinute() {
		return this.tunnelIdleMinute;
	}

	public void setTunnelIdleMinute(int tunnelIdleMinute) {
		this.tunnelIdleMinute = tunnelIdleMinute;
	}

	public int getTunnelTurnMinute() {
		return this.tunnelTurnMinute;
	}

	public void setTunnelTurnMinute(int tunnelTurnMinute) {
		this.tunnelTurnMinute = tunnelTurnMinute;
	}

	public Double getWasherEfficiencyThreshold() {
		return this.washerEfficiencyThreshold;
	}

	public void setWasherEfficiencyThreshold(Double washerEfficiencyThreshold) {
		this.washerEfficiencyThreshold = washerEfficiencyThreshold;
	}

	public int getWasherIdleMinute() {
		return this.washerIdleMinute;
	}

	public void setWasherIdleMinute(int washerIdleMinute) {
		this.washerIdleMinute = washerIdleMinute;
	}

	public int getWasherTurnMinute() {
		return this.washerTurnMinute;
	}

	public void setWasherTurnMinute(int washerTurnMinute) {
		this.washerTurnMinute = washerTurnMinute;
	}

	public String getZipcode() {
		return this.zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	@Override
	public String toString() {
		return "SiteMaster [siteId=" + siteId + ", address1=" + address1 + ", address2=" + address2 + ", alertSetting="
				+ alertSetting + ", city=" + city + ", country=" + country + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", description=" + description + ", indexCreated=" + indexCreated
				+ ", isActive=" + isActive + ", isDeleted=" + isDeleted + ", latitude=" + latitude + ", longitude="
				+ longitude + ", metricUnit=" + metricUnit + ", modifiedBy=" + modifiedBy + ", modifiedDate="
				+ modifiedDate + ", siteName=" + siteName + ", siteUniqueId=" + siteUniqueId + ", state=" + state
				+ ", streamingEnabled=" + streamingEnabled + ", timeZone=" + timeZone + ", tunnelEfficiencyThreshold="
				+ tunnelEfficiencyThreshold + ", tunnelIdleMinute=" + tunnelIdleMinute + ", tunnelTurnMinute="
				+ tunnelTurnMinute + ", washerEfficiencyThreshold=" + washerEfficiencyThreshold + ", washerIdleMinute="
				+ washerIdleMinute + ", washerTurnMinute=" + washerTurnMinute + ", zipcode=" + zipcode + "]";
	}

}