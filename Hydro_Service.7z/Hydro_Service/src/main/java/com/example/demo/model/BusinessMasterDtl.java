package com.example.demo.model;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonFormat;

//@JsonFormat(shape=JsonFormat.Shape.ARRAY)
public class BusinessMasterDtl implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<BusinessMaster> businessMasters;

	public List<BusinessMaster> getBusinessMasters() {
		return businessMasters;
	}

	public void setBusinessMasters(List<BusinessMaster> businessMasters) {
		this.businessMasters = businessMasters;
	}

	public BusinessMasterDtl(List<BusinessMaster> businessMasters) {
		super();
		this.businessMasters = businessMasters;
	}

	public BusinessMasterDtl() {
		super();
		
	}
	
	
}
