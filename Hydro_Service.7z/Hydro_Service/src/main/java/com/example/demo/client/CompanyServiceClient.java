package com.example.demo.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.BusinessMaster;
import com.example.demo.model.BusinessMasterDtl;
import com.example.demo.model.SiteMasterDtl;

@Component
public class CompanyServiceClient {

	@Autowired
	RestTemplate restTemplate;
	
	public ResponseEntity<BusinessMaster> getCompanyServiceDetailById(String businessId){
		String url = "http://companyService/cs/getCompanyServiceDetailById/" + businessId;
		ResponseEntity<BusinessMaster> restExchange = restTemplate.getForEntity(url, BusinessMaster.class);
		return restExchange;
	}
	
	

	public ResponseEntity<BusinessMasterDtl> getAllCompanyServiceDetail() {

		String url="http://companyService/cs/getAllCompanyServiceDetail";
		ResponseEntity<BusinessMasterDtl> restExchange = restTemplate.getForEntity(url, BusinessMasterDtl.class);
		return restExchange;
	}
}
