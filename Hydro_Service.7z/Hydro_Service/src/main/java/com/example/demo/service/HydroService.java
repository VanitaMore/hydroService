package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.client.CompanyServiceClient;
import com.example.demo.client.SiteServiceClient;
import com.example.demo.model.BusinessMaster;
import com.example.demo.model.BusinessMasterDtl;
import com.example.demo.model.SiteMasterDtl;
import com.example.demo.model.CompanyAndSiteServiceDetails;
import com.example.demo.model.SiteMaster;

@Service
public class HydroService {

	@Autowired SiteServiceClient siteServiceClient;
	@Autowired CompanyServiceClient companyServiceClient;
	
	
public CompanyAndSiteServiceDetails	getAllServicedetail(){
		CompanyAndSiteServiceDetails bothServiceDetail=new CompanyAndSiteServiceDetails(); 
		
		ResponseEntity<SiteMasterDtl> siteServiceList=siteServiceClient.getAllSiteServiceDetail();
		
		System.out.println(siteServiceList.getBody());
		
		SiteMasterDtl siteMasterDtl=siteServiceList.getBody();
		//List<SiteMasterDtl> list=new ArrayList<SiteMasterDtl>();
		//list.add(siteServiceList.getBody());
		
	//	List<SiteMaster> siteMasterList = siteMasterDtl.getSiteMasterList();
		//SiteMasterDtl sdt = new SiteMasterDtl();
		//sdt.setSiteMasterList(siteMasterList);
		bothServiceDetail.setSiteMasterDtl(siteMasterDtl);
		
	
		
		ResponseEntity<BusinessMasterDtl> businessMasterlist=companyServiceClient.getAllCompanyServiceDetail();
		BusinessMasterDtl businessMasterDtl=businessMasterlist.getBody();
		bothServiceDetail.setBusinessMasterDtl(businessMasterDtl);
		
		
		return bothServiceDetail;
		
	}

}
