package com.example.demo.client;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.SiteMaster;
import com.example.demo.model.SiteMasterDtl;

@Component
public class SiteServiceClient {

	@Autowired
	RestTemplate restTemplate;

	//SiteServiceDetail
	public ResponseEntity<SiteMaster> getSiteServiceDetailById(String siteId) {

		String url = "http://siteService/ss/getSiteServiceDetailById/" + siteId;
		ResponseEntity<SiteMaster> restExchange = restTemplate.getForEntity(url, SiteMaster.class);
		System.out.println(restExchange.getBody());
		return restExchange;
	}

	public ResponseEntity<SiteMasterDtl> getAllSiteServiceDetail() {

		String url="http://siteService/ss/getAllSiteServiceDetail";
	
		ResponseEntity<SiteMasterDtl> restExchange = restTemplate.getForEntity(url, SiteMasterDtl.class);
		System.out.println(restExchange.getBody());
		return restExchange;
	}
}
