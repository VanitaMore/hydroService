package com.example.demo.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;

//@JsonFormat(shape=JsonFormat.Shape.ARRAY)
public class CompanyAndSiteServiceDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private SiteMasterDtl siteMasterDtl;
	private BusinessMasterDtl businessMasterDtl;
	
	public CompanyAndSiteServiceDetails(SiteMasterDtl siteMasterDtl, BusinessMasterDtl businessMasterDtl) {
		super();
		this.siteMasterDtl = siteMasterDtl;
		this.businessMasterDtl = businessMasterDtl;
	}
	public SiteMasterDtl getSiteMasterDtl() {
		return siteMasterDtl;
	}
	public void setSiteMasterDtl(SiteMasterDtl siteMasterDtl) {
		this.siteMasterDtl = siteMasterDtl;
	}
	public BusinessMasterDtl getBusinessMasterDtl() {
		return businessMasterDtl;
	}
	public void setBusinessMasterDtl(BusinessMasterDtl businessMasterDtl) {
		this.businessMasterDtl = businessMasterDtl;
	}
	public CompanyAndSiteServiceDetails() {
		super();
		
	}

	
	
	
	
	
}
