package com.example.demo.model;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonFormat;


public class SiteMasterDtl implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	List<SiteMaster> siteMasterList;

	public List<SiteMaster> getSiteMasterList() {
		return siteMasterList;
	}

	public void setSiteMasterList(List<SiteMaster> siteMasterList) {
		this.siteMasterList = siteMasterList;
	}

	public SiteMasterDtl() {
		super();
		
	}

	public SiteMasterDtl(List<SiteMaster> siteMasterList) {
		super();
		this.siteMasterList = siteMasterList;
	}
	
	

}
